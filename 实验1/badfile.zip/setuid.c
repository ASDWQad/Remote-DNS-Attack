/*setuid.c*/
void main(){
    setuid(0);
    system("/bin/sh");
}
