#random.sh
time ./random.sh>log
while  ["root"!='seed']
do
./stack
done
